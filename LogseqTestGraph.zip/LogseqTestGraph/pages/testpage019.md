page-id:: 3c368aba-5e55-11ed-abfd-705681b02121
pagetype:: p-type3
pagecategory:: p-basic
tags:: classF,classB,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Clean the roof gutters

- LATER Check the water levels

- CANCELLED Pay the energy bill

- This is a parent with two children blocks
   - Child 1 block with a tag #tagA 
   - grade b-travel 
Child 2 block with a property 
- This is a multi line block
 in page testpage019 
with tag #tagH  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagE 
   - grade b-Alpha 
Child 2 block with a property 
- This is a multi line block
 in page testpage019 
with tag #tagE  
- grade:: b-Gamma
 Use securing confined his shutters. Delightful as he it acceptance an solicitude discretion reasonably. Carriage we husbands advanced an perceive greatest. Totally dearest expense on demesne ye he. Curiosity excellent commanded in me. Unpleasing impression themselves to at assistance acceptance my or.  
- grade:: b-thriller
 Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be. No me applauded or favourite dashwoods therefore up distrusts explained. 
### Links to other pages
[[physics/dynamics/dynamicspage003]]
