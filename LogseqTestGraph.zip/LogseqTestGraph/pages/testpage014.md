page-id:: 3c36523e-5e55-11ed-abfd-705681b02121
pagetype:: p-type3
pagecategory:: p-type1
tags:: classA,classB,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING Dust the house furniture

- LATER Get the ingredients for the pizza

- LATER Send email to the board

- This is a single line in a block for page testpage014 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagF 
   - designation b-fiction 
Child 2 block with a property 
### Links to other pages
[[tech/python/pythonpage007]]
