page-id:: 3c36f31a-5e55-11ed-abfd-705681b02121
pagetype:: p-minor
pagecategory:: p-type2
tags:: classF,classB,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Clean the roof gutters

- TODO [[physics/dynamics/dynamicspage013]] Send email to the board

- TODO [[physics/dynamics/dynamicspage013]] Reconcile the transaction account

- WAITING Do the Shopping

- This is a single line in a block 
- This is an indented list of items
    - Item A Article evident arrived express highest men did boy. 
        - Item A1 Article evident arrived express highest men did boy. 
        - Item A2 Article evident arrived express highest men did boy. 
    - Item B Article evident arrived express highest men did boy. 
    - Item C Article evident arrived express highest men did boy. 
        - Item C1 Article evident arrived express highest men did boy. 
    - Item D Article evident arrived express highest men did boy. 
 
- This is a single line block in page tech%2Ftechpage014 with tag #tagF  
- #tagA  Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all. 
- This is a multi line block
 in page tech%2Ftechpage014 
with tag #tagB  
### Links to other pages
[[testpage014]]
