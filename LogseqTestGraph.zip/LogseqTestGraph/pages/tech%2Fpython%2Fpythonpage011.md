page-id:: 3c373f82-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-type4
tags:: classG,classD,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[physics/dynamics/dynamicspage011]] Check the water levels

- TODO Pay the energy bill

- TODO Reconcile the transaction account

- WAITING [[physics/dynamics/dynamicspage011]] Dust the house furniture

- TODO Clean the roof gutters

- LATER Reconcile the transaction account

- 
Extremity as if breakfast agreement. Off now mistress provided out horrible opinions. Prevailed mr tolerably discourse assurance estimable applauded to so. Him everything melancholy uncommonly but solicitude inhabiting projection off. Connection stimulated estimating excellence an to impression. 
### Links to other pages
[[Queries/queryexample013]]
