page-id:: 3c374202-5e55-11ed-abfd-705681b02121
pagetype:: p-major
pagecategory:: p-type4
tags:: classC,classD,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Reconcile the transaction account

- CANCELLED Check the water levels

- DONE Dust the house furniture

- LATER Get the ingredients for the pizza

- DONE Reconcile the transaction account

- LATER Prepare the garden bed for spring

- This is a multi line block
 in page tech%2Fpython%2Fpythonpage012 
with tag #tagH  
- This is a single line block in page tech%2Fpython%2Fpythonpage012 with tag #tagD  
### Links to other pages
[[testpage008]]
