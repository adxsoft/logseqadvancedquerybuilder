page-id:: 3c3731d6-5e55-11ed-abfd-705681b02121
pagetype:: p-major
pagecategory:: p-type1
tags:: classG,classF,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[physics/dynamics/dynamicspage011]] Collect the fees from the club members

- LATER Check the water levels

- DONE Reconcile the transaction account

- TODO Get the ingredients for the pizza

- TODO Clean the roof gutters

- DONE Prepare the garden bed for spring

- This is a single line in a block 
- 
On consider laughter civility offended oh. 
- This is a single line block in page tech%2Fpython%2Fpythonpage009 with tag #tagH  
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage009 
with tag #tagB  
### Links to other pages
[[testpage018]]
