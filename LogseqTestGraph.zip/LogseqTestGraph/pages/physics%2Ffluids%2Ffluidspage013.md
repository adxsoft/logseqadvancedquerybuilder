page-id:: 3c382be0-5e55-11ed-abfd-705681b02121
pagetype:: p-type3
pagecategory:: p-type4
tags:: classF,classG,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Dust the house furniture

- WAITING Collect the fees from the club members

- DONE Collect the fees from the club members

- WAITING Check the water levels

- TODO Pay the energy bill

- This is a single line block in page physics%2Ffluids%2Ffluidspage013 with tag #tagD  
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage013 
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage013 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - grade b-fiction 
Child 2 block with a property 
- This is a single line block in page physics%2Ffluids%2Ffluidspage013 with tag #tagG  
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage013 
### Links to other pages
[[tech/python/pythonpage004]]
