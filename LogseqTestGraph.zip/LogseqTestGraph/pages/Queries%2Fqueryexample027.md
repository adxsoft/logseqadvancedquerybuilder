page-id:: 3c38d7d4-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: hide breadcrumbs
- pages
    - testpage00*
- hidebreadcrumb

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "hide breadcrumbs"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:breadcrumb-show? false
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "hide breadcrumbs"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:breadcrumb-show? false
}
#+END_QUERY



### Links to other pages
[[testpage009]]
