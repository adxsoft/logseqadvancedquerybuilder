page-id:: 3c37e996-5e55-11ed-abfd-705681b02121
pagetype:: p-advanced
pagecategory:: p-type2
tags:: classC,classH,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Dust the house furniture

- This is a single line in a block 
### Links to other pages
[[physics/dynamics/dynamicspage012]]
