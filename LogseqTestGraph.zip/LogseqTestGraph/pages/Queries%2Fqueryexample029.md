page-id:: 3c38e1d4-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: All blocks - test access to parent pages tags, journal
- blocks
    - *
- tasks
    - TODO
- pagetags
    - classC

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "All blocks - test access to parent pages tags, journal"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/marker ?marker]
[(contains? #{"TODO"} ?marker)]
[?page :block/journal? false]
(page-tags ?page #{"classc"})
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "All blocks - test access to parent pages tags, journal"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/marker ?marker]
[(contains? #{"TODO"} ?marker)]
[?page :block/journal? false]
(page-tags ?page #{"classc"})
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage011]]
