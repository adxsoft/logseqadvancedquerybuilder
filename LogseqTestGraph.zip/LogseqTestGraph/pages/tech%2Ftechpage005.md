page-id:: 3c36c066-5e55-11ed-abfd-705681b02121
pagetype:: p-type2
pagecategory:: p-advanced
tags:: classE,classE,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Pay the energy bill

- LATER Prepare the garden bed for spring

- LATER Check the water levels

- CANCELLED Reconcile the transaction account

- LATER Check the water levels

- WAITING [[physics/dynamics/dynamicspage011]] Check the water levels

- category:: b-Alpha
 Engrossed suffering supposing he recommend do eagerness. Commanded no of depending extremity recommend attention tolerably. Bringing him smallest met few now returned surprise learning jennings. Objection delivered eagerness he exquisite at do in. Warmly up he nearer mr merely me. 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagE 
   - category b-fiction 
Child 2 block with a property 
### Links to other pages
[[tech/python/pythonpage015]]
