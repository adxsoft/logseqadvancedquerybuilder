page-id:: 3c367bf6-5e55-11ed-abfd-705681b02121
pagetype:: p-major
pagecategory:: p-type3
tags:: classE,classF,classE

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Do the Shopping

- LATER Post the bank letters

- TODO [[physics/dynamics/dynamicspage013]] Post the bank letters

- TODO [[physics/dynamics/dynamicspage013]] Pay the energy bill

- This is a single line in a block 
- This is a single line in a block for page testpage018 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - designation b-western 
Child 2 block with a property 
### Links to other pages
[[Queries/queryexample027]]
