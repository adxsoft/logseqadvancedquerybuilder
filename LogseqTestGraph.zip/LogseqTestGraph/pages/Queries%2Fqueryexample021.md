page-id:: 3c38bbaa-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find journals
- pages
    - *
- journalonly

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find journals"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? true]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find journals"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? true]
]
}
#+END_QUERY



### Links to other pages
[[testpage014]]
