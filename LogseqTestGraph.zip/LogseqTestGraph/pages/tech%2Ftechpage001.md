page-id:: 3c36ab3a-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-major
tags:: classE,classA,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Collect the fees from the club members

- LATER Clean the roof gutters

- This is a single line block in page tech%2Ftechpage001 with tag #tagF  
### Links to other pages
[[Queries/queryexample038]]
