page-id:: 3c392018-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]

- Query Commands
	- ```
	  title: block tag combinations using and and or
	  - blocks
	      - *
	  - blocktags
	      - tagA
	      - or tagB
	      - and tagD
	  
	  ```
- Generated Query
	- ```clojure
	  
	  #+BEGIN_QUERY
	  {
	  :title [:b "block tag combinations using and and or"]
	  :query [:find (pull ?block [*])
	  :where
	  [?block :block/content ?blockcontent]
	  [?block :block/page ?page]
	  [?page :block/name ?pagename]
	  ( or 
	  (page-ref ?block "taga")
	  (page-ref ?block "tagb")
	  )
	  (page-ref ?block "tagd")
	  ]
	  }
	  #+END_QUERY
	  
	  ```
- Query Results
	- #+BEGIN_QUERY
	  {
	  :title [:b "block tag combinations using and and or"]
	  :query [:find (pull ?block [*])
	  :where
	  [?block :block/content ?blockcontent]
	  [?block :block/page ?page]
	  [?page :block/name ?pagename]
	  ( or 
	  (page-ref ?block "taga")
	  (page-ref ?block "tagb")
	  )
	  ;;(page-ref ?block "tagd")
	  ]
	  }
	  #+END_QUERY
### Links to other pages
[[testpage001]]