page-id:: 3c36de70-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-minor
tags:: classE,classB,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[physics/dynamics/dynamicspage011]] Send email to the board

- WAITING [[physics/dynamics/dynamicspage011]] Reconcile the transaction account

- TODO Collect the fees from the club members

- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - designation b-Beta 
Child 2 block with a property 
- #tagC  Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery. 
### Links to other pages
[[Queries/queryexample037]]
