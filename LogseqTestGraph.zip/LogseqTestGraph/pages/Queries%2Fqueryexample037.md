page-id:: 3c3907a4-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: journalsbetween defaulting to blocks retrieval
- journalsbetween
    - :today :30d-after

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
;; WARNING: Must have 'pages' command or 'blocks' Command
;;          otherwise the query cannot get any information
;;          Inserting a blocks command for you

{
:title [:b "journalsbetween defaulting to blocks retrieval"]
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal-day ?journaldate]
[(>= ?journaldate ?startdate)]
[(<= ?journaldate ?enddate)]
]
:inputs [:today :30d-after]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
;; WARNING: Must have 'pages' command or 'blocks' Command
;;          otherwise the query cannot get any information
;;          Inserting a blocks command for you

{
:title [:b "journalsbetween defaulting to blocks retrieval"]
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal-day ?journaldate]
[(>= ?journaldate ?startdate)]
[(<= ?journaldate ?enddate)]
]
:inputs [:today :30d-after]
}
#+END_QUERY



### Links to other pages
[[tech/techpage009]]
