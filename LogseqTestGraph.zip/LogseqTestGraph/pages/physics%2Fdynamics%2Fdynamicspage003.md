page-id:: 3c377b5a-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-type2
tags:: classF,classD,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[physics/dynamics/dynamicspage011]] Pay the energy bill

- TODO [[physics/dynamics/dynamicspage013]] Collect the fees from the club members

- #tagE  Use securing confined his shutters. Delightful as he it acceptance an solicitude discretion reasonably. Carriage we husbands advanced an perceive greatest. Totally dearest expense on demesne ye he. Curiosity excellent commanded in me. Unpleasing impression themselves to at assistance acceptance my or.  
- This is a single line in a block 
- This is a single line in a block for page physics%2Fdynamics%2Fdynamicspage003 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - designation b-travel 
Child 2 block with a property 
- #tagA  And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we.  
### Links to other pages
[[testpage006]]
