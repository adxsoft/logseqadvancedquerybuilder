page-id:: 3c388f9a-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: select and exclude task types
- pages
    - testpage00*
- tasks
    - TODO
    - not DOING

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY

;; **ERROR: tasks not valid with pages command use blocks command instead

{
:title [:b "select and exclude task types"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY

;; **ERROR: tasks not valid with pages command use blocks command instead

{
:title [:b "select and exclude task types"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY



- Query Commands
    - ```
title: select and exclude task types
- pages
    - testpage00*
- tasks
    - TODO
    - not DOING

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY

;; **ERROR: tasks not valid with pages command use blocks command instead

{
:title [:b "select and exclude task types"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY

;; **ERROR: tasks not valid with pages command use blocks command instead

{
:title [:b "select and exclude task types"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY



### Links to other pages
[[Queries/queryexample024]]
