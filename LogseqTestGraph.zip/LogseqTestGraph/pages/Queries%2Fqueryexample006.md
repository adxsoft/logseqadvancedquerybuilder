page-id:: 3c3871e0-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: blocks command - ignore blocks using wildcards
- blocks
    - not And sir dare view*
    - not *here leave merit enjoy forth.
    - not *roof gutters*

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "blocks command - ignore blocks using wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(not [(clojure.string/ends-with? ?blockcontent "And sir dare view")])
(not [(clojure.string/starts-with? ?blockcontent "here leave merit enjoy forth.")])
(not [(clojure.string/includes? ?blockcontent "roof gutters")])
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "blocks command - ignore blocks using wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(not [(clojure.string/ends-with? ?blockcontent "And sir dare view")])
(not [(clojure.string/starts-with? ?blockcontent "here leave merit enjoy forth.")])
(not [(clojure.string/includes? ?blockcontent "roof gutters")])
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage008]]
