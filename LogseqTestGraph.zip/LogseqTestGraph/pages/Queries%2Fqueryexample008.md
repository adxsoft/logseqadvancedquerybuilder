page-id:: 3c387c1c-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: blocktags and pages don't mix
- pages
    - testpage00*
- blocktags
    - tagA
    - not tagB

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY

;; **ERROR: blocktags not valid with pages command use blocks command instead

{
:title [:b "blocktags and pages don't mix"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY

;; **ERROR: blocktags not valid with pages command use blocks command instead

{
:title [:b "blocktags and pages don't mix"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage007]]
