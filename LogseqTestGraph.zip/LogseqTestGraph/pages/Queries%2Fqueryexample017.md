page-id:: 3c38a82c-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find scheduled blocks in a namespace
- blocks
    - *
- namespace
    - physics
- scheduled

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find scheduled blocks in a namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
[?block :block/scheduled ?scheduleddate]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find scheduled blocks in a namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
[?block :block/scheduled ?scheduleddate]
]
}
#+END_QUERY



### Links to other pages
[[tech/techpage008]]
