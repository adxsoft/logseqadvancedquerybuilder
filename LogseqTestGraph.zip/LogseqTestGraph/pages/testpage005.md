page-id:: 3c362138-5e55-11ed-abfd-705681b02121
pagetype:: p-advanced
pagecategory:: p-type4
tags:: classC,classE,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Pay the energy bill

- DONE Check the water levels

- #tagB  Sympathize it projection ye insipidity celebrated my pianoforte indulgence. Point his truth put style. Elegance exercise as laughing proposal mistaken if. We up precaution an it solicitude acceptance invitation. 
- This is a single line in a block 
- This is a single line in a block for page testpage005 
### Links to other pages
[[Queries/queryexample023]]
