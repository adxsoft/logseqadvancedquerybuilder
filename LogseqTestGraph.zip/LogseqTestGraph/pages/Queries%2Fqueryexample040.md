page-id:: 3c391636-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: page tag combinations using and and or
- pages
    - *
- pagetags
    - classA
    - or classB
    - and classH

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "page tag combinations using and and or"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? false]
( or 
(page-tags ?block #{"classa"})
(page-tags ?block #{"classb"})
)
(page-tags ?block #{"classh"})
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "page tag combinations using and and or"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? false]
( or 
(page-tags ?block #{"classa"})
(page-tags ?block #{"classb"})
)
(page-tags ?block #{"classh"})
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage018]]
