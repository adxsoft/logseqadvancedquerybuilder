page-id:: 3c3902cc-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY



- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY



- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY



- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY



- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage007]]
