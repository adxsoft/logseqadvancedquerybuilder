page-id:: 3c3729ca-5e55-11ed-abfd-705681b02121
pagetype:: p-advanced
pagecategory:: p-type4
tags:: classB,classH,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Clean the roof gutters

- LATER Pay the energy bill

- DONE Prepare the garden bed for spring

- LATER Clean the roof gutters

- WAITING [[physics/dynamics/dynamicspage011]] Dust the house furniture

- 
Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age.  
### Links to other pages
[[physics/fluids/fluidspage006]]
