page-id:: 3c370bac-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-type1
tags:: classG,classG,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Dust the house furniture

- DONE Get the ingredients for the pizza

- This is an indented list of items
    - Item A On consider laughter civility offended oh.
        - Item A1 On consider laughter civility offended oh.
        - Item A2 On consider laughter civility offended oh.
    - Item B On consider laughter civility offended oh.
    - Item C On consider laughter civility offended oh.
        - Item C1 On consider laughter civility offended oh.
    - Item D On consider laughter civility offended oh.
 
### Links to other pages
[[Queries/queryexample038]]
