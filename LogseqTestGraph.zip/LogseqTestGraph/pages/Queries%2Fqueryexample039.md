page-id:: 3c39117c-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: page property combinations using and and or
- pages
    - *
- pageproperties
    - pagecategory, "p-minor"
    - or pagecategory, "p-minimum"
    - and pagetype, "p-type1"

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "page property combinations using and and or"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
(page-property ?block :pagecategory "p-minor")
(page-property ?block :pagecategory "p-minimum")
)
(page-property ?block :pagetype "p-type1")
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "page property combinations using and and or"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
(page-property ?block :pagecategory "p-minor")
(page-property ?block :pagecategory "p-minimum")
)
(page-property ?block :pagetype "p-type1")
]
}
#+END_QUERY



### Links to other pages
[[tech/techpage013]]
