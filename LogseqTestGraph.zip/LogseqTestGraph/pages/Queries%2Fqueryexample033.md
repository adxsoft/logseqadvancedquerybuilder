page-id:: 3c38f48a-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: Pages only - select all pages
- pages
    - *

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "Pages only - select all pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "Pages only - select all pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
]
}
#+END_QUERY



### Links to other pages
[[physics/dynamics/dynamicspage013]]
