page-id:: 3c37187c-5e55-11ed-abfd-705681b02121
pagetype:: p-minor
pagecategory:: p-minor
tags:: classE,classC,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING Clean the roof gutters

- DONE Prepare the garden bed for spring

- This is a multi line block
 in page tech%2Fpython%2Fpythonpage002 
with tag #tagG  
- This is a single line in a block 
### Links to other pages
[[physics/dynamics/dynamicspage013]]
