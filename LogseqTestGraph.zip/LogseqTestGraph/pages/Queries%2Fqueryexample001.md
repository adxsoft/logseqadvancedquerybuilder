page-id:: 3c3857be-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - specific pages
- pages
    - testpage001
    - testpage002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - specific pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
[?block :block/name "testpage001"]
[?block :block/name "testpage002"]
)
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - specific pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
[?block :block/name "testpage001"]
[?block :block/name "testpage002"]
)
]
}
#+END_QUERY



- Query Commands
    - ```
title: pages command - specific pages
- pages
    - testpage001
    - testpage002

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - specific pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
[?block :block/name "testpage001"]
[?block :block/name "testpage002"]
)
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - specific pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
[?block :block/name "testpage001"]
[?block :block/name "testpage002"]
)
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage015]]
