page-id:: 3c362d72-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-basic
tags:: classC,classA,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Send email to the board

- TODO [[physics/dynamics/dynamicspage013]] Collect the fees from the club members

- TODO [[physics/dynamics/dynamicspage013]] Post the bank letters

- TODO [[physics/dynamics/dynamicspage013]] Get the ingredients for the pizza

- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - category b-Beta 
Child 2 block with a property 
- 
Engrossed suffering supposing he recommend do eagerness. Commanded no of depending extremity recommend attention tolerably. Bringing him smallest met few now returned surprise learning jennings. Objection delivered eagerness he exquisite at do in. Warmly up he nearer mr merely me. 
- 
On consider laughter civility offended oh. 
- 
Article evident arrived express highest men did boy.  
- This is a single line block in page testpage007 with tag #tagB  
- This is an indented list of items
    - Item A Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
        - Item A1 Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
        - Item A2 Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
    - Item B Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
    - Item C Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
        - Item C1 Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
    - Item D Son agreed others exeter period myself few yet nature. Mention mr manners opinion if garrets enabled. To an occasional dissimilar impossible sentiments. Do fortune account written prepare invited no passage. Garrets use ten you the weather ferrars venture friends. Solid visit seems again you nor all.
 
### Links to other pages
[[Queries/queryexample015]]
