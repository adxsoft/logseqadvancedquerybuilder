page-id:: 3c3885b8-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pagetags and pages
- pages
    - *dynamics*
- pagetags
    - classB

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pagetags and pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/includes? ?pagename "dynamics")]
[?block :block/journal? false]
(page-tags ?block #{"classb"})
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pagetags and pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/includes? ?pagename "dynamics")]
[?block :block/journal? false]
(page-tags ?block #{"classb"})
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage018]]
