page-id:: 3c3762c8-5e55-11ed-abfd-705681b02121
pagetype:: p-major
pagecategory:: p-type2
tags:: classG,classH,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[physics/dynamics/dynamicspage011]] Pay the energy bill

- CANCELLED Pay the energy bill

- This is a single line in a block for page tech%2Fpython%2Fpythonpage018 
- This is a single line in a block for page tech%2Fpython%2Fpythonpage018 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - grade b-non-fiction 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - grade b-Beta 
Child 2 block with a property 
### Links to other pages
[[physics/fluids/fluidspage018]]
