page-id:: 3c392540-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]

- Query Commands
	- ```
	  title: task and or combintions
	  - blocks
	      - *
	  - tasks
	      - TODO
	      - and WAITING
	      - or LATER
	      - not DOING
	  
	  ```
- Generated Query
	- ```clojure
	  
	  #+BEGIN_QUERY
	  {
	  :title [:b "task and or combintions"]
	  :query [:find (pull ?block [*])
	  :where
	  [?block :block/content ?blockcontent]
	  [?block :block/page ?page]
	  [?page :block/name ?pagename]
	  [?block :block/marker ?marker]
	  ( or 
	  [(contains? #{"TODO"} ?marker)]
	  [(contains? #{"LATER"} ?marker)]
	  )
	  [(contains? #{"WAITING"} ?marker)]
	  (not [(contains? #{"DOING"} ?marker)])
	  ]
	  }
	  #+END_QUERY
	  
	  ```
- Query Results
	- #+BEGIN_QUERY
	  {
	  :title [:b "task and or combintions"]
	  :query [:find (pull ?block [*])
	  :where
	  [?block :block/content ?blockcontent]
	  [?block :block/page ?page]
	  [?page :block/name ?pagename]
	  [?block :block/marker ?marker]
	  ( or 
	  [(contains? #{"TODO"} ?marker)]
	  [(contains? #{"LATER"} ?marker)]
	  )
	  [(contains? #{"WAITING"} ?marker)]
	  (not [(contains? #{"DOING"} ?marker)])
	  ]
	  }
	  #+END_QUERY
### Links to other pages
[[tech/techpage008]]