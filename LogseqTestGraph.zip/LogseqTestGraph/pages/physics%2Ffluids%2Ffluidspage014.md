page-id:: 3c38331a-5e55-11ed-abfd-705681b02121
pagetype:: p-minor
pagecategory:: p-type2
tags:: classE,classD,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Collect the fees from the club members

- TODO Prepare the garden bed for spring

- CANCELLED Pay the energy bill

- This is a multi line block
 in page physics%2Ffluids%2Ffluidspage014 
with tag #tagF  
- This is a multi line block
 in page physics%2Ffluids%2Ffluidspage014 
with tag #tagA  
- This is a single line in a block 
- This is a single line in a block 
- 
Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age.  
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage014 
### Links to other pages
[[Queries/queryexample012]]
