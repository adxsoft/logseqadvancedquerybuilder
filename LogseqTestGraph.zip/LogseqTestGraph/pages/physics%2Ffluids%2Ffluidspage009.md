page-id:: 3c3817ea-5e55-11ed-abfd-705681b02121
pagetype:: p-type1
pagecategory:: p-type2
tags:: classA,classA,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[physics/dynamics/dynamicspage011]] Send email to the board

- CANCELLED Send email to the board

- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - category b-Alpha 
Child 2 block with a property 
- This is a multi line block
 in page physics%2Ffluids%2Ffluidspage009 
with tag #tagE  
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage009 
### Links to other pages
[[Queries/queryexample011]]
