page-id:: 3c37687c-5e55-11ed-abfd-705681b02121
pagetype:: p-basic
pagecategory:: p-minor
tags:: classD,classF,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Collect the fees from the club members

- DONE Pay the energy bill

- LATER Send email to the board

- TODO [[physics/dynamics/dynamicspage013]] Pay the energy bill

- This is a multi line block
 in page tech%2Fpython%2Fpythonpage019 
with tag #tagD  
### Links to other pages
[[physics/fluids/fluidspage001]]
