page-id:: 3c38c9d8-5e55-11ed-abfd-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: collapse results
- pages
    - testpage00*
- collapse

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "collapse results"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:collapsed? true
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "collapse results"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:collapsed? true
}
#+END_QUERY



### Links to other pages
[[testpage004]]
