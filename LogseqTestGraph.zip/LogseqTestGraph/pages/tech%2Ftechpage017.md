page-id:: 3c37051c-5e55-11ed-abfd-705681b02121
pagetype:: p-type4
pagecategory:: p-type1
tags:: classA,classA,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Dust the house furniture

- CANCELLED Send email to the board

- DONE Check the water levels

- CANCELLED Prepare the garden bed for spring

- WAITING Dust the house furniture

- TODO Prepare the garden bed for spring

- This is a single line block in page tech%2Ftechpage017 with tag #tagF  
- category:: b-non-fiction
 On consider laughter civility offended oh. 
### Links to other pages
[[Queries/queryexample001]]
